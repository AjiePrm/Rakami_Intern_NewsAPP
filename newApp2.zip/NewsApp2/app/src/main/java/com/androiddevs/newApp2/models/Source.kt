package com.androiddevs.newApp2.models

data class Source(
    val id: Any,
    val name: String
)