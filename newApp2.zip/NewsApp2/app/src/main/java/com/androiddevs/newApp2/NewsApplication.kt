package com.androiddevs.newApp2

import android.app.Application

class NewsApplication : Application()