package com.androiddevs.newApp2.util

class Constants {
    companion object {
        const val API_KEY = "c5bba58851194f7c961b06a062b19e00"
        const val BASE_URL = "https://newsapi.org"
        const val SEARCH_NEWS_TIME_DELAY = 500L
        const val QUERY_PAGE_SIZE = 20
    }
}